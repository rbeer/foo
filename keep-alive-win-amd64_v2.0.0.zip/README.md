# Keep-Alive

Utility to keep a Windows session from locking.

This is achieved by issuing a left-shift keyboard input event, every 60 seconds.

## Install

Download a release build (e.g. `keep-alive-win-amd64_v0.1.0.zip`) and unpack the archive. You will find these files:

- `keep-alive-win-amd64.exe` - the program
- `README.md` - this file
- `LICENSE` - the necessary legalese

## Use

Run `keep-alive-win-amd64.exe` - that's it.

You can toggle the program by left-clicking its notification icon in the task bar.

| State   | Icon                                 |
| ------- | ------------------------------------ |
| Running | ![Running](./winres/active_64.png)   |
| Stopped | ![Stopped](./winres/inactive_64.png) |

Right-clicking ends the program.

## Develop

This repo is being developed on Windows (:weary:), using the git-bash from [Git for Windows](https://gitforwindows.org/), i.e. all the dependencies (make, perl, ...) are part of it.

### go-winres

This repo uses [go-winres](https://github.com/tc-hib/go-winres) to create the Windows manifest and embedded icons.

You can install it, using:

`go install github.com/tc-hib/go-winres@latest`

### Make

This repo comes with a couple of make targets:

| Target | Job |
| --- | --- |
| build | Builds to ./bin. This is meant to test builds during development. `$VERSION` for these development builds is the latest commit hash. Builds at the same commit are overwritten without asking. |
| clean | Cleans builds. This does not clean releases. |
| run | Short for `go run .` |
| release | Builds to ./dist/$VERSION/. `$VERSION`is the latest git-tag in this repo. `release`is not meant to be used directly, as it does not take care of bumping the version before building/packaging. Call`./release.sh`, instead! |
